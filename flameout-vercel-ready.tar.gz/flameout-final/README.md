# 🔥 Flameout - Burnout Recovery App

Your personal companion for burnout recovery.

## 🚀 Deploy to Vercel

1. Push to GitHub
2. Import to Vercel
3. Deploy!

## 📁 Files

- `index.html` - Main HTML file
- `flameout-app.js` - React app (with localStorage support)
- `vercel.json` - Vercel configuration

## ✨ Features

- Phase 1: 14 Recovery Exercises
- Pet System with Evolution
- Energy Tracking
- Journal & Breathing
- Progress Dashboard
- Data Export

**Version:** 1.0.0  
**Status:** Production Ready
